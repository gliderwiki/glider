INSERT INTO WE_GROUP_INFO ( 
     we_group_code
    ,we_group_name
    ,we_group_type
    ,we_group_owner
    ,we_required_yn
    ,we_group_info
    ,we_use_yn
    ,we_ins_user
    ,we_ins_date
) VALUES ( 
     NULL
    ,'총무팀'
    ,'0'
    ,4
    ,NULL
    ,'총무팀 조직 입니다.'
    ,'Y'
    ,1
    ,NOW()
);
    
DESC WE_GROUP_INFO    