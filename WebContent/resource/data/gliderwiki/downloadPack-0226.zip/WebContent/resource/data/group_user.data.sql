INSERT INTO `we_group_user` 
	(`WE_GROUP_IDX`, 
	`WE_USER_IDX`, 
	`WE_USE_YN`, 
	`WE_INS_DATE`, 
	`WE_INS_USER`
	)
	VALUES
	(9, 
	1, 
	'Y', 
	NOW(),
	1
	);
